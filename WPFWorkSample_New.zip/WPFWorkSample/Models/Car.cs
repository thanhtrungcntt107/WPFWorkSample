﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFWorkSample.Models
{
    public class Car: INotifyPropertyChanged
    {
        public int Id { get; set; }

        private string _manufacture;
        public string Manufacture
        {
            get { return _manufacture; }
            set
            {
                if (_manufacture != value)
                {
                    _manufacture = value;
                    RaisePropertyChanged("Manufacture");
                }
            }
        }

        private string _model;
        public string Model
        {
            get { return _model; }
            set
            {
                if (_model != value)
                {
                    _model = value;
                    RaisePropertyChanged("Model");
                }
            }
        }

        private int _weight;
        public int Weight
        {
            get { return _weight; }
            set
            {
                if (_weight != value)
                {
                    _weight = value;
                    RaisePropertyChanged("Weight");
                }
            }
        }

        public bool IsEdit { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;
        private void RaisePropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
    }
}
