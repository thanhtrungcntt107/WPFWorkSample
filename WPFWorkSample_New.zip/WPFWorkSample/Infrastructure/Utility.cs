﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFWorkSample.Infrastructure
{
    public enum Manufacture
    {
        Honda,
        Toyota,
        Mitsubishi,
        GeneralMotors,
        BMW,
        Ferrari
    }
}
